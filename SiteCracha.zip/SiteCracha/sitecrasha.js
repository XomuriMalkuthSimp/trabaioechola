

// puxa as coisa do html
let inNome = document.getElementById("inNome");
let inCurso = document.getElementById("inCurso");
let inRA = document.getElementById("inRA");

let outNome = document.getElementById("outNome");
let outCurso = document.getElementById("outCurso");
let outRA = document.getElementById("outRA");

//le os baguiu que o caba escreve com input e os faz escrever simultaneamente
inNome.addEventListener("input", function(){
    outNome.textContent = inNome.value;
});

inCurso.addEventListener("input", function(){
    outCurso.textContent = inCurso.value;
});

inRA.addEventListener("input", function(){
    outRA.textContent = inRA.value;
});

// e isso daqui é pra faze o botão inverte as cor taligado
let botao = document.getElementById("dadoAluno");
let cracha = document.querySelector(".Crpre");

botao.addEventListener("click", function(){

    // muda o fundo do crachá Bro
    cracha.style.background =" linear-gradient( 15deg,rgb(54, 51, 233),rgb(162, 21, 21))";

    botao.remove();
});